package onlineShop.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import onlineShop.model.Cart;
import onlineShop.model.CartItem;

@Repository
public class CartItemDaoImpl implements CartItemDao {
	@Autowired
	private SessionFactory sessionFactory;

	public void addCartItem(CartItem item) {
		Session session = null;

		try {
			// open JDBC connection and start to transact
			session = sessionFactory.openSession();
			session.beginTransaction();
			session.saveOrUpdate(item);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}

	public void removeCartItem(int itemId) {
		Session session = null;
		try {
			session = sessionFactory.openSession();
			CartItem item = (CartItem) session.get(CartItem.class, itemId);
			Cart cart = item.getCart();
			List<CartItem> items = cart.getCartItem();
			items.remove(item);
			session.beginTransaction();
			session.delete(item);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(session != null) {
				session.close();
			}
		}
	}

	public void removeAllCartItems(Cart cart) {
		List<CartItem> items = cart.getCartItem();
		for (CartItem item : items) {
			removeCartItem(item.getId());
		}
	}
}
